import Header from "./Header";
import Footer from "./Footer";
import { Helmet, HelmetProvider } from "react-helmet-async";

const Layout = ({ children, title, keywords, author, description }) => {
  return (
    <HelmetProvider>
      <Helmet>
        <meta charSet="utf-8" />
        <meta name="description" content={description} />
        <meta name="keywords" content={keywords} />
        <meta name="author" content={author} />
        <title>{title}</title>
      </Helmet>
      <Header />
      <main style={{ minHeight: "70vh" }}>{children}</main>
      <Footer />
    </HelmetProvider>
  );
};

Layout.defaultProps = {
  title: "Shopyee MEARN stack app",
  description: "MEARN Stack project for shopping",
  keywords: "Node, Rect, Express, API, Mongo",
  author: "CodexHunter",
};

export default Layout;
