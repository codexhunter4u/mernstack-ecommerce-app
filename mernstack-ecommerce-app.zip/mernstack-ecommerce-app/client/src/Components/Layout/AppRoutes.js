import React from "react";
import Home from "../../Pages/Home";
import About from "../../Pages/About";
import Contact from "../../Pages/Contact";
import Register from "../../Pages/Auth/Register";
import PageNotFound from "../../Pages/PageNotFound";
import Policy from "../../Pages/Policy";
import Dashboard from "../../Pages/User/Dashboard";
import AdminDashboard from "../../Pages/Admin/AdminDashboard";
import { Routes, Route } from "react-router-dom";
import Login from "../../Pages/Auth/Login";
import ForgotPassword from "../../Pages/Auth/ForgotPassword";
import ProtectUserRoute from "../Routes/ProtectUserRoute";
import ProtectAdminRoute from "../Routes/ProtectAdminRoute";
import CreateCategory from "../../Pages/Admin/CreateCategory";
import CreateProduct from "../../Pages/Admin/CreateProduct";
import Users from "../../Pages/Admin/Users";
import Orders from "../../Pages/User/Orders";
import Profile from "../../Pages/User/Profile";
import Products from "../../Pages/Admin/Products";
import UpdateProduct from "../../Pages/Admin/UpdateProducts";
import Search from "../../Pages/Search";
import ProductDetails from "../../Pages/ProductDetails";
import Categories from "../../Pages/Categories";
import CategoryProduct from "../../Pages/CategoryProduct";
import Cart from "../../Pages/Cart";
import AdminOrders from "../../Pages/Admin/AdminOrders";

function AppRoutes() {
  return (
    <>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/search" element={<Search />} />
        <Route path="/product/:slug" element={<ProductDetails />} />
        <Route path="/categories" element={<Categories />} />
        <Route path="/category/:slug" element={<CategoryProduct />} />
        <Route path="/dashboard" element={<ProtectUserRoute />}>
          <Route path="user" element={<Dashboard />} />
          <Route path="user/orders" element={<Orders />} />
          <Route path="user/profile" element={<Profile />} />
        </Route>
        <Route path="/dashboard" element={<ProtectAdminRoute />}>
          <Route path="admin" element={<AdminDashboard />} />
          <Route path="admin/create-category" element={<CreateCategory />} />
          <Route path="admin/create-product" element={<CreateProduct />} />
          <Route path="admin/users" element={<Users />} />
          <Route path="admin/products" element={<Products />} />
          <Route path="admin/product/:slug" element={<UpdateProduct />} />
          <Route path="admin/orders" element={<AdminOrders />} />
        </Route>
        <Route path="/register" element={<Register />} />
        <Route path="/forgot-password" element={<ForgotPassword />} />
        <Route path="/login" element={<Login />} />
        <Route path="/about" element={<About />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/policy" element={<Policy />} />
        <Route path="*" element={<PageNotFound />} />
      </Routes>
    </>
  );
}

export default AppRoutes;
