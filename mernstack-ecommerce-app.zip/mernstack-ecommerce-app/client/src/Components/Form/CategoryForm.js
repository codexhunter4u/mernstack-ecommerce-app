import React from "react";

const CategoryForm = ({ handleSubmit, value, setValue }) => {
  return (
    <>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label
            htmlFor="categoryName"
            style={{ marginBottom: "5px", fontWeight: "700" }}
          >
            Category Name
          </label>
          <input
            type="text"
            className="form-control"
            id="categoryName"
            aria-describedby="emailHelp"
            placeholder="Enter name"
            value={value}
            onChange={(e) => setValue(e.target.value)}
          />
        </div>
        <button type="submit" className="btn btn-primary mt-3">
          Submit
        </button>
      </form>
    </>
  );
};

export default CategoryForm;
