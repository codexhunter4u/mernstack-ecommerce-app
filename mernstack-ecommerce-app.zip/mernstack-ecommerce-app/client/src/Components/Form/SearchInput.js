import React from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { useSearch } from "../../Contex/Search";

const SearchInput = () => {
  const [values, setValues] = useSearch();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    try {
      if (values.keyword.length) {
        const { data } = await axios.get(
          `/api/v1/product/search/${values.keyword}`
        );
        setValues({ ...values, results: data });
        navigate("/search");
      } else {
        navigate("/");
      }
    } catch (error) {
      console.log(error);
    }
  };

  return (
    <div>
      <form className="d-flex" role="search">
        <input
          className="form-control me-2"
          type="search"
          placeholder="Search"
          aria-label="Search"
          value={values.keyword}
          onChange={(e) => setValues({ ...values, keyword: e.target.value })}
          onKeyUp={handleSubmit}
        />
      </form>
    </div>
  );
};

export default SearchInput;
