import React from "react";
import "../slider.css";
import { Carousel, Image } from "react-bootstrap";

const ProductSlider = ({ order }) => {
  return (
    <div>
      <Carousel className="customers-carousel-container" interval={null}>
        {order?.products?.map((p, i) => (
          <Carousel.Item className="customers-carousel-item" key={i}>
            <div className="container">
              <div className="row mb-2 p-3 card flex-row" key={p._id}>
                <div className="col-md-1"></div>
                <div className="col-md-4">
                  <Image
                    src={`/api/v1/product/photo/${p._id}`}
                    className="d-block customers-carousel-img"
                    alt={p.name}
                  />
                </div>
                <div className="col-md-6 product-desc">
                  <p>{p.name}</p>
                  <p>{p.description.substring(0, 30)}</p>
                  <p>Price : {p.price}</p>
                </div>
              </div>
            </div>
          </Carousel.Item>
        ))}
      </Carousel>
    </div>
  );
};

export default ProductSlider;
