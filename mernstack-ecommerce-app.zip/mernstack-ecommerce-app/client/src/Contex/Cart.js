import { useState, useContext, createContext } from "react";

const SearchContext = createContext();

const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);

  return (
    <SearchContext.Provider value={[cart, setCart]}>
      {children}
    </SearchContext.Provider>
  );
};

// Custom search hook
const useCart = () => useContext(SearchContext);

export { useCart, CartProvider };
